﻿
$(document).ready(function () {

    $("input#showGreenLineMap").change(function () {
        if (this.checked) {
            document.getElementById("map-canvas").style.display = "block";
            ConstructGreenLineGoogleMaps();
        }
        else {
            document.getElementById("map-canvas").style.display = "none";
        }
    });

    $("input#showOrangeLineMap").change(function () {
        if (this.checked) {
            document.getElementById("map-canvas").style.display = "block";
            ConstructOrangeLineGoogleMaps();
        }
        else {
            document.getElementById("map-canvas").style.display = "none";
        }
    });

    $("input#showRedLineMap").change(function () {
        if (this.checked) {
            document.getElementById("map-canvas").style.display = "block";
            ConstructRedLineGoogleMaps();
        }
        else {
            document.getElementById("map-canvas").style.display = "none";
        }
    });

    $("input#showBlueLineMap").change(function () {
        if (this.checked) {
            document.getElementById("map-canvas").style.display = "block";
            ConstructBlueLineGoogleMaps();
        }
        else {
            document.getElementById("map-canvas").style.display = "none";
        }
    });

});


// Below method fetches the coordinates of boarding and destination place, later the maps helper function is called 
//  to plot those location in google maps
function ConstructGreenLineGoogleMaps() {

    // Retrieving the Boarding Place Coordinates
    var boardingPlaceCoordinates = GetGreenLineBoardingPlaceCoordinates();

    // Retrieving the Destination Place Coordinates
    var destinationPlaceCoordinates = GetGreenLineDestinationPlaceCoordinates();

    // Helper function which is responsible for plotting the values in google maps with green line drawn between boarding and destination points
    if ((boardingPlaceCoordinates != undefined) && (destinationPlaceCoordinates != undefined)) {

        var boardingPlaceCoordinatesArray = boardingPlaceCoordinates.split("\n");
        var boardingPlaceLatitude = boardingPlaceCoordinatesArray[0];
        var boardingPlaceLongitude = boardingPlaceCoordinatesArray[1];

        var destinationPlaceCoordinatesArray = destinationPlaceCoordinates.split("\n");
        var destinationPlaceLatitude = destinationPlaceCoordinatesArray[0];
        var destinationPlaceLongitude = destinationPlaceCoordinatesArray[1];


        PlotValuesInGoogleMaps(boardingPlaceLatitude, boardingPlaceLongitude, destinationPlaceLatitude, destinationPlaceLongitude, "green");
    }
}



// Returns the latitude and longitude of the boarding place
function GetGreenLineBoardingPlaceCoordinates() {

    /*
    var boardingPlaceLatitude = "42.334228515625";
    var boardingPlaceLongitude = "-71.104606628418";
    */

    var boardingPlaceCoordinates;
    // Retrieving the Boarding place latitude and longitude
    var boardingPlaceFromUser = $("input#txtBoardingPointStopName").val().trim();
    if (boardingPlaceFromUser != '') {
        var baseURL = "services/get-green-line-stop-coordinates.aspx?StopName=" + boardingPlaceFromUser;
        boardingPlaceCoordinates = GetXMLHttpResponseAsText(baseURL);
    }
    return boardingPlaceCoordinates;
}



// Returns the latitude and longitude of the destination place
function GetGreenLineDestinationPlaceCoordinates() {

    /*
    var destinationPlaceLatitude = "42.3499755859375";
    var destinationPlaceLongitude = "-71.0774459838867";
    */

    // Retrieving the Destination place latitude and longitude
    var destinationPlaceCoordinates;
    var destinationPlaceFromUser = $("input#txtDestinationPointStopName").val().trim();
    if (destinationPlaceFromUser != '') {
        var baseURL = "services/get-green-line-stop-coordinates.aspx?StopName=" + destinationPlaceFromUser;
        destinationPlaceCoordinates = GetXMLHttpResponseAsText(baseURL);
    }
    return destinationPlaceCoordinates;
}



// Below method fetches the coordinates of boarding and destination place, later the maps helper function is called 
//  to plot those location in google maps
function ConstructOrangeLineGoogleMaps() {

    // Retrieving the Boarding Place Coordinates
    var boardingPlaceCoordinates = GetOrangeLineBoardingPlaceCoordinates();

    // Retrieving the Destination Place Coordinates
    var destinationPlaceCoordinates = GetOrangeLineDestinationPlaceCoordinates();

    // Helper function which is responsible for plotting the values in google maps with green line drawn between boarding and destination points
    if ((boardingPlaceCoordinates != undefined) && (destinationPlaceCoordinates != undefined)) {

        var boardingPlaceCoordinatesArray = boardingPlaceCoordinates.split("\n");
        var boardingPlaceLatitude = boardingPlaceCoordinatesArray[0];
        var boardingPlaceLongitude = boardingPlaceCoordinatesArray[1];

        var destinationPlaceCoordinatesArray = destinationPlaceCoordinates.split("\n");
        var destinationPlaceLatitude = destinationPlaceCoordinatesArray[0];
        var destinationPlaceLongitude = destinationPlaceCoordinatesArray[1];


        PlotValuesInGoogleMaps(boardingPlaceLatitude, boardingPlaceLongitude, destinationPlaceLatitude, destinationPlaceLongitude, "orange");
    }
}



// Returns the latitude and longitude of the boarding place
function GetOrangeLineBoardingPlaceCoordinates() {

    /*
    var boardingPlaceLatitude = "42.334228515625";
    var boardingPlaceLongitude = "-71.104606628418";
    */

    var boardingPlaceCoordinates;
    // Retrieving the Boarding place latitude and longitude
    var boardingPlaceFromUser = $("input#txtBoardingPointStopName").val().trim();
    if (boardingPlaceFromUser != '') {
        var baseURL = "services/get-orange-line-stop-coordinates.aspx?StopName=" + boardingPlaceFromUser;
        boardingPlaceCoordinates = GetXMLHttpResponseAsText(baseURL);
    }
    return boardingPlaceCoordinates;
}



// Returns the latitude and longitude of the destination place
function GetOrangeLineDestinationPlaceCoordinates() {

    /*
    var destinationPlaceLatitude = "42.3499755859375";
    var destinationPlaceLongitude = "-71.0774459838867";
    */

    // Retrieving the Destination place latitude and longitude
    var destinationPlaceCoordinates;
    var destinationPlaceFromUser = $("input#txtDestinationPointStopName").val().trim();
    if (destinationPlaceFromUser != '') {
        var baseURL = "services/get-orange-line-stop-coordinates.aspx?StopName=" + destinationPlaceFromUser;
        destinationPlaceCoordinates = GetXMLHttpResponseAsText(baseURL);
    }
    return destinationPlaceCoordinates;
}



// Below method fetches the coordinates of boarding and destination place, later the maps helper function is called 
//  to plot those location in google maps
function ConstructRedLineGoogleMaps() {

    // Retrieving the Boarding Place Coordinates
    var boardingPlaceCoordinates = GetRedLineBoardingPlaceCoordinates();

    // Retrieving the Destination Place Coordinates
    var destinationPlaceCoordinates = GetRedLineDestinationPlaceCoordinates();

    // Helper function which is responsible for plotting the values in google maps with green line drawn between boarding and destination points
    if ((boardingPlaceCoordinates != undefined) && (destinationPlaceCoordinates != undefined)) {

        var boardingPlaceCoordinatesArray = boardingPlaceCoordinates.split("\n");
        var boardingPlaceLatitude = boardingPlaceCoordinatesArray[0];
        var boardingPlaceLongitude = boardingPlaceCoordinatesArray[1];

        var destinationPlaceCoordinatesArray = destinationPlaceCoordinates.split("\n");
        var destinationPlaceLatitude = destinationPlaceCoordinatesArray[0];
        var destinationPlaceLongitude = destinationPlaceCoordinatesArray[1];


        PlotValuesInGoogleMaps(boardingPlaceLatitude, boardingPlaceLongitude, destinationPlaceLatitude, destinationPlaceLongitude, "red");
    }
}



// Returns the latitude and longitude of the boarding place
function GetRedLineBoardingPlaceCoordinates() {

    /*
    var boardingPlaceLatitude = "42.334228515625";
    var boardingPlaceLongitude = "-71.104606628418";
    */

    var boardingPlaceCoordinates;
    // Retrieving the Boarding place latitude and longitude
    var boardingPlaceFromUser = $("input#txtBoardingPointStopName").val().trim();
    if (boardingPlaceFromUser != '') {
        var baseURL = "services/get-red-line-stop-coordinates.aspx?StopName=" + boardingPlaceFromUser;
        boardingPlaceCoordinates = GetXMLHttpResponseAsText(baseURL);
    }
    return boardingPlaceCoordinates;
}



// Returns the latitude and longitude of the destination place
function GetRedLineDestinationPlaceCoordinates() {

    /*
    var destinationPlaceLatitude = "42.3499755859375";
    var destinationPlaceLongitude = "-71.0774459838867";
    */

    // Retrieving the Destination place latitude and longitude
    var destinationPlaceCoordinates;
    var destinationPlaceFromUser = $("input#txtDestinationPointStopName").val().trim();
    if (destinationPlaceFromUser != '') {
        var baseURL = "services/get-red-line-stop-coordinates.aspx?StopName=" + destinationPlaceFromUser;
        destinationPlaceCoordinates = GetXMLHttpResponseAsText(baseURL);
    }
    return destinationPlaceCoordinates;
}



// Below method fetches the coordinates of boarding and destination place, later the maps helper function is called 
//  to plot those location in google maps
function ConstructBlueLineGoogleMaps() {

    // Retrieving the Boarding Place Coordinates
    var boardingPlaceCoordinates = GetBlueLineBoardingPlaceCoordinates();

    // Retrieving the Destination Place Coordinates
    var destinationPlaceCoordinates = GetBlueLineDestinationPlaceCoordinates();

    // Helper function which is responsible for plotting the values in google maps with green line drawn between boarding and destination points
    if ((boardingPlaceCoordinates != undefined) && (destinationPlaceCoordinates != undefined)) {

        var boardingPlaceCoordinatesArray = boardingPlaceCoordinates.split("\n");
        var boardingPlaceLatitude = boardingPlaceCoordinatesArray[0];
        var boardingPlaceLongitude = boardingPlaceCoordinatesArray[1];

        var destinationPlaceCoordinatesArray = destinationPlaceCoordinates.split("\n");
        var destinationPlaceLatitude = destinationPlaceCoordinatesArray[0];
        var destinationPlaceLongitude = destinationPlaceCoordinatesArray[1];


        PlotValuesInGoogleMaps(boardingPlaceLatitude, boardingPlaceLongitude, destinationPlaceLatitude, destinationPlaceLongitude, "blue");
    }
}



// Returns the latitude and longitude of the boarding place
function GetBlueLineBoardingPlaceCoordinates() {

    /*
    var boardingPlaceLatitude = "42.334228515625";
    var boardingPlaceLongitude = "-71.104606628418";
    */

    var boardingPlaceCoordinates;
    // Retrieving the Boarding place latitude and longitude
    var boardingPlaceFromUser = $("input#txtBoardingPointStopName").val().trim();
    if (boardingPlaceFromUser != '') {
        var baseURL = "services/get-blue-line-stop-coordinates.aspx?StopName=" + boardingPlaceFromUser;
        boardingPlaceCoordinates = GetXMLHttpResponseAsText(baseURL);
    }
    return boardingPlaceCoordinates;
}



// Returns the latitude and longitude of the destination place
function GetBlueLineDestinationPlaceCoordinates() {

    /*
    var destinationPlaceLatitude = "42.3499755859375";
    var destinationPlaceLongitude = "-71.0774459838867";
    */

    // Retrieving the Destination place latitude and longitude
    var destinationPlaceCoordinates;
    var destinationPlaceFromUser = $("input#txtDestinationPointStopName").val().trim();
    if (destinationPlaceFromUser != '') {
        var baseURL = "services/get-blue-line-stop-coordinates.aspx?StopName=" + destinationPlaceFromUser;
        destinationPlaceCoordinates = GetXMLHttpResponseAsText(baseURL);
    }
    return destinationPlaceCoordinates;
}



// Make a HTTP GET Request for the URL and returns the response as plain text
function GetXMLHttpResponseAsText(baseURL) {
    var xmlHttp = null;
    xmlHttp = new XMLHttpRequest();
    xmlHttp.open("GET", baseURL, false);
    xmlHttp.send(null);
    return xmlHttp.responseText;
}



// Helper function which is responsible for plotting the values in google maps with a line drawn between boarding and destination points
function PlotValuesInGoogleMaps(boardingPlaceLatitude, boardingPlaceLongitude, destinationPlaceLatitude, destinationPlaceLongitude, strokePolyLineColor) {

    var directionsDisplay = new google.maps.DirectionsRenderer({
        polylineOptions: {
            strokeColor: strokePolyLineColor,
            strokeOpacity: 1.0,
            strokeWeight: 2
        }
    });

    var directionsService = new google.maps.DirectionsService();
    var map;
    var fromPlace = new google.maps.LatLng(boardingPlaceLatitude, boardingPlaceLongitude);
    var destinationPlace = new google.maps.LatLng(destinationPlaceLatitude, destinationPlaceLongitude);
    // The below variable forces the maps to show the train routes
    var transportationMode = "TRANSIT";
    var mapOptions = {
        center: fromPlace,
        zoom: 15,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    }

    // Updating the map division in the front end
    var map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
    directionsDisplay.setMap(map);

    // Preparing the request object to consume direction service
    var request = {
        origin: fromPlace,
        destination: destinationPlace,
        travelMode: google.maps.TravelMode[transportationMode]
    };

    // Requesting for the route
    directionsService.route(request, function (response, status) {
        if (status == google.maps.DirectionsStatus.OK) {
            directionsDisplay.setDirections(response);
        }
    });

}



