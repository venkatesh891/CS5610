﻿
$(document).ready(function () {

});


// The below function auto populates the Green Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteGreenLineEBoardingStopNames() {
    var stopNameFromUser = $("input#txtBoardingPointStopName").val().trim();

    jQuery.ajax({
        url: 'services/get-green-line-e-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtBoardingPointStopName").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }
    });
}


// The below function auto populates the Green Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteGreenLineEDestinationStopNames() {
    var stopNameFromUser = $("input#txtDestinationPointStopName").val().trim();

    jQuery.ajax({
        url: 'services/get-green-line-e-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtDestinationPointStopName").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }

    });
}



// The below function auto populates the Green Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteGreenLineBoardingStopNames() {
    var stopNameFromUser = $("input#txtBoardingPointStopName").val().trim();

    jQuery.ajax({
        url: 'services/get-green-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtBoardingPointStopName").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }
    });
}


// The below function auto populates the Green Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteGreenLineDestinationStopNames() {
    var stopNameFromUser = $("input#txtDestinationPointStopName").val().trim();

    jQuery.ajax({
        url: 'services/get-green-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtDestinationPointStopName").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }

    });
}


// The below function auto populates the Orange Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteOrangeLineBoardingStopNames() {
    var stopNameFromUser = $("input#txtBoardingPointStopName").val().trim();

    jQuery.ajax({
        url: 'services/get-orange-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtBoardingPointStopName").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }
    });
}


// The below function auto populates the Orange Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteOrangeLineDestinationStopNames() {
    var stopNameFromUser = $("input#txtDestinationPointStopName").val().trim();

    jQuery.ajax({
        url: 'services/get-orange-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtDestinationPointStopName").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }

    });
}


// The below function auto populates the Red Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteRedLineBoardingStopNames() {
    var stopNameFromUser = $("input#txtBoardingPointStopName").val().trim();

    jQuery.ajax({
        url: 'services/get-red-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtBoardingPointStopName").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }
    });
}


// The below function auto populates the Red Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteRedLineDestinationStopNames() {
    var stopNameFromUser = $("input#txtDestinationPointStopName").val().trim();

    jQuery.ajax({
        url: 'services/get-red-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtDestinationPointStopName").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }

    });
}


// The below function auto populates the Blue Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteBlueLineBoardingStopNames() {
    var stopNameFromUser = $("input#txtBoardingPointStopName").val().trim();
    jQuery.ajax({
        url: 'services/get-blue-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtBoardingPointStopName").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }
    });
}


// The below function auto populates the Blue Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteBlueLineDestinationStopNames() {
    var stopNameFromUser = $("input#txtDestinationPointStopName").val().trim();

    jQuery.ajax({
        url: 'services/get-blue-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtDestinationPointStopName").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
             alert(errorMessage);
        }

    });
}


// The below function clears the boarding, destination, table result contents
// This function will be triggered upon the "Clear" button click event
function ClearGreenLineEContents() {
    document.getElementById('txtBoardingPointStopName').value = "";
    document.getElementById('txtDestinationPointStopName').value = "";
    document.getElementById('firstJourneyTitle').innerHTML = "";
    document.getElementById('tripResultsTable').innerHTML = "";
    document.getElementById('status').innerHTML = "<b> Status: Waiting for the end user to hit 'Find Trains' button.. </b> <br/>";
}


// The below function clears the boarding, destination, table result contents
// This function will be triggered upon the "Clear" button click event
function ClearGreenLineContents()
{
    document.getElementById('txtBoardingPointStopName').value = "";
    document.getElementById('txtDestinationPointStopName').value = "";
    document.getElementById('firstJourneyTitle').innerHTML = "";
    document.getElementById('tripResultsTable').innerHTML = "";
    document.getElementById('secondJourneyTitle').innerHTML = "";
    document.getElementById('hopTripResultsTable').innerHTML = "";
    document.getElementById("map-canvas").innerHTML = "";
    document.getElementById('status').innerHTML = "<b> Status: Waiting for the end user to hit 'Find Trains' button.. </b> <br/>";
}


// The below function clears the boarding, destination, table result contents
// This function will be triggered upon the "Clear" button click event
function ClearOrangeLineContents() {
    document.getElementById('txtBoardingPointStopName').value = "";
    document.getElementById('txtDestinationPointStopName').value = "";
    document.getElementById('firstJourneyTitle').innerHTML = "";
    document.getElementById('tripResultsTable').innerHTML = "";
    document.getElementById("map-canvas").innerHTML = "";
    document.getElementById('status').innerHTML = "<b> Status: Waiting for the end user to hit 'Find Trains' button.. </b> <br/>";
}


// The below function clears the boarding, destination, table result contents
// This function will be triggered upon the "Clear" button click event
function ClearRedLineContents() {
    document.getElementById('txtBoardingPointStopName').value = "";
    document.getElementById('txtDestinationPointStopName').value = "";
    document.getElementById('firstJourneyTitle').innerHTML = "";
    document.getElementById('tripResultsTable').innerHTML = "";
    document.getElementById("map-canvas").innerHTML = "";
    document.getElementById('status').innerHTML = "<b> Status: Waiting for the end user to hit 'Find Trains' button.. </b> <br/>";
}


// The below function clears the boarding, destination, table result contents
// This function will be triggered upon the "Clear" button click event
function ClearBlueLineContents() {
    document.getElementById('txtBoardingPointStopName').value = "";
    document.getElementById('txtDestinationPointStopName').value = "";
    document.getElementById('firstJourneyTitle').innerHTML = "";
    document.getElementById('tripResultsTable').innerHTML = "";
    document.getElementById("map-canvas").innerHTML = "";
    document.getElementById('status').innerHTML = "<b> Status: Waiting for the end user to hit 'Find Trains' button.. </b> <br/>";
}


