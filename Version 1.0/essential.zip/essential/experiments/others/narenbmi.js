﻿$(document).ready(function () {

    if (isPostBack) {
        CalculateBMI();
    }
    else {
        WeightChange();
        FeetChange();
        InchesChange();
    }
});


// The below function updates the weight value in front end when slider is dragged
function WeightChange() {
    var weight = document.getElementById('rangeWeight').valueAsNumber;
    document.getElementById('txtWeight').value = weight;
}


// The below function updates the feet value in front end when slider is dragged
function FeetChange() {
    var feet = document.getElementById('rangeFeet').valueAsNumber;
    document.getElementById('txtFeet').value = feet;
}


// The below function updates the inches value in front end when slider is dragged
function InchesChange() {
    var inches = document.getElementById('rangeInches').valueAsNumber;
    document.getElementById('txtInches').value = inches;
}


// The below function computes the BMI based on weight and height
function CalculateBMI() {
    try {
        document.getElementById('bmiStatus').style.display = "block";

        var heightFeet = parseInt(document.getElementById('txtFeet').value, 10);
        var heightInches = parseInt(document.getElementById('txtInches').value, 10);
        var weightPounds = parseInt(document.getElementById('txtWeight').value, 10);

        console.log(heightFeet);
        console.log(heightInches);
        console.log(weightPounds);

        var bmi = 0;

        var totalHeightInches = (heightFeet * 12) + heightInches;

        if ((weightPounds > 15) && (weightPounds < 700)) {

            if (totalHeightInches < 132) {

                bmi = (weightPounds / (totalHeightInches * totalHeightInches)) * 703.069;
                console.log(bmi);
                if (bmi < 18.5) {
                    document.getElementById('bmiStatus').innerHTML = "Your BMI is " + bmi.toFixed(2) + ". Your weight is less than normal for your height";
                }

                else if ((bmi >= 18.5) && (bmi <= 24.9)) {
                    document.getElementById('bmiStatus').innerHTML = "Your BMI is " + bmi.toFixed(2) + ". Your weight is normal for your height. Your BMI is perfect!";
                }

                else if ((bmi >= 25) && (bmi <= 29.9)) {
                    document.getElementById('bmiStatus').innerHTML = "Your BMI is " + bmi.toFixed(2) + ". Your weight is a bit more than normal for your height. Your need to shed some weight.";
                }
                else {
                    document.getElementById('bmiStatus').innerHTML = "Your BMI is " + bmi.toFixed(2) + ". Your weight is too much than normal for your height. Please consult a dietitian and follow a good diet.";
                }
            }
            else {

                document.getElementById('bmiStatus').innerHTML = "Please enter a valid height";

            }

        }
        else {
            document.getElementById('bmiStatus').innerHTML = "Please enter a valid weight in pounds";
        }

        
    }
    catch (e) {
        console.log(e);
        document.getElementById('bmiStatus').innerHTML = "Lets do it again.Please enter a valid height and weight";
    }
}
