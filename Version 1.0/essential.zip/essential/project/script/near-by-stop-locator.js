﻿
// These are the global variables on which I hold the nearest stop details of green, orange, red and blue line
var greenLineLeastMileDistance;
var greenLineNearestStopDetails;
var orangeLineLeastMileDistance;
var orangeLineNearestStopDetails;
var redLineLeastMileDistance;
var redLineNearestStopDetails;
var blueLineLeastMileDistance;
var blueLineNearestStopDetails;

// The below is the conversion factor for meters to miles
var converstionFactor = 0.000621371;


function PlotTheNearestStopInGoogleMaps() {
    navigator.geolocation.getCurrentPosition(GetCurrentUserLocation);
}


// Retrieves the current location of the user by consuming the HTML GeoLocation
function GetCurrentUserLocation(position) {
    var currentLatLong = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
    ComputeTheNearestStopLocations(currentLatLong);
}


// The below function is responsible for computing the nearest stop in all the lines from the end user's position
function ComputeTheNearestStopLocations(currentPosition) {
    ComputeGreenLineNearestStop(currentPosition);
    ComputeOrangeLineNearestStop(currentPosition);
    ComputeRedLineNearestStop(currentPosition);
    ComputeBlueLineNearestStop(currentPosition);

    /*
    console.log(greenLineNearestStopDetails);
    console.log(orangeLineNearestStopDetails);
    console.log(redLineNearestStopDetails);
    console.log(blueLineNearestStopDetails); */

    // The latitude and longitude of each stop in the table is located at third and fourth column
    var greenPosition = new google.maps.LatLng(greenLineNearestStopDetails[2], greenLineNearestStopDetails[3]);
    var orangePosition = new google.maps.LatLng(orangeLineNearestStopDetails[2], orangeLineNearestStopDetails[3]);
    var redPosition = new google.maps.LatLng(redLineNearestStopDetails[2], redLineNearestStopDetails[3]);
    var bluePosition = new google.maps.LatLng(blueLineNearestStopDetails[2], blueLineNearestStopDetails[3]);
    DrawTheGoogleMaps(currentPosition, greenPosition, orangePosition, redPosition, bluePosition);
}


// The below function is responsible for computing the nearest green line stop from the end user's position
function ComputeGreenLineNearestStop(currentPosition) {
    var greenLineServiceURL = "services/get-green-line-stop-details.aspx";
    greenLineDBStations = GetXMLHttpResponseAsText(greenLineServiceURL);
    // The service returns record from DB where each row is separated by '\n'
    var splittedGreenLineSingleStop = $.trim(greenLineDBStations).split("\n");

    var greenLineStopsRowCount = splittedGreenLineSingleStop.length
    for (var i = 0 ; i < greenLineStopsRowCount; i++) {
        // The service returns record from DB where each row has multiple columns where all the columns are separated by '|'
        var greenLineSingleElement = $.trim(splittedGreenLineSingleStop[i]).split("|");
        // The latitude and longitude of each stop in the table is located at third and fourth column
        var greeLineDBLatLong = new google.maps.LatLng(greenLineSingleElement[2], greenLineSingleElement[3]);
        var meters = google.maps.geometry.spherical.computeDistanceBetween(currentPosition, greeLineDBLatLong);
        var miles = meters * converstionFactor;
        miles = miles.toFixed(2);
        if (i == 0) {
            greenLineLeastMileDistance = miles;
            greenLineNearestStopDetails = greenLineSingleElement;
        }
        else {
            if (miles < greenLineLeastMileDistance) {
                greenLineLeastMileDistance = miles;
                greenLineNearestStopDetails = greenLineSingleElement;
            }
        }
    }
}


// The below function is responsible for computing the nearest orange line stop from the end user's position
function ComputeOrangeLineNearestStop(currentPosition) {
    var orangeLineServiceURL = "services/get-orange-line-stop-details.aspx";
    orangeLineDBStations = GetXMLHttpResponseAsText(orangeLineServiceURL);
    // The service returns record from DB where each row is separated by '\n'
    var splittedOrangeLineSingleStop = $.trim(orangeLineDBStations).split("\n");

    var orangeLineStopsRowCount = splittedOrangeLineSingleStop.length
    for (var i = 0 ; i < orangeLineStopsRowCount; i++) {
        // The service returns record from DB where each row has multiple columns where all the columns are separated by '|'
        var orangeLineSingleElement = $.trim(splittedOrangeLineSingleStop[i]).split("|");
        // The latitude and longitude of each stop in the table is located at third and fourth column
        var orangeLineDBLatLong = new google.maps.LatLng(orangeLineSingleElement[2], orangeLineSingleElement[3]);
        var meters = google.maps.geometry.spherical.computeDistanceBetween(currentPosition, orangeLineDBLatLong);
        var miles = meters * converstionFactor;
        miles = miles.toFixed(2);
        if (i == 0) {
            orangeLineLeastMileDistance = miles;
            orangeLineNearestStopDetails = orangeLineSingleElement;
        }
        else {
            if (miles < orangeLineLeastMileDistance) {
                orangeLineLeastMileDistance = miles;
                orangeLineNearestStopDetails = orangeLineSingleElement;
            }
        }
    }
}


// The below function is responsible for computing the nearest red line stop from the end user's position
function ComputeRedLineNearestStop(currentPosition) {
    var redLineServiceURL = "services/get-red-line-stop-details.aspx";
    redLineDBStations = GetXMLHttpResponseAsText(redLineServiceURL);
    // The service returns record from DB where each row is separated by '\n'
    var splittedRedLineSingleStop = $.trim(redLineDBStations).split("\n");

    var redLineStopsRowCount = splittedRedLineSingleStop.length
    for (var i = 0 ; i < redLineStopsRowCount; i++) {
        // The service returns record from DB where each row has multiple columns where all the columns are separated by '|'
        var redLineSingleElement = $.trim(splittedRedLineSingleStop[i]).split("|");
        // The latitude and longitude of each stop in the table is located at third and fourth column
        var redLineDBLatLong = new google.maps.LatLng(redLineSingleElement[2], redLineSingleElement[3]);
        var meters = google.maps.geometry.spherical.computeDistanceBetween(currentPosition, redLineDBLatLong);
        var miles = meters * converstionFactor;
        miles = miles.toFixed(2);
        if (i == 0) {
            redLineLeastMileDistance = miles;
            redLineNearestStopDetails = redLineSingleElement;
        }
        else {
            if (miles < redLineLeastMileDistance) {
                redLineLeastMileDistance = miles;
                redLineNearestStopDetails = redLineSingleElement;
            }
        }
    }
}


// The below function is responsible for computing the nearest blue line stop from the end user's position
function ComputeBlueLineNearestStop(currentPosition) {
    var blueLineServiceURL = "services/get-blue-line-stop-details.aspx";
    blueLineDBStations = GetXMLHttpResponseAsText(blueLineServiceURL);
    // The service returns record from DB where each row is separated by '\n'
    var splittedBlueLineSingleStop = $.trim(blueLineDBStations).split("\n");

    var blueLineStopsRowCount = splittedBlueLineSingleStop.length
    for (var i = 0 ; i < blueLineStopsRowCount; i++) {
        // The service returns record from DB where each row has multiple columns where all the columns are separated by '|'
        var blueLineSingleElement = $.trim(splittedBlueLineSingleStop[i]).split("|");
        // The latitude and longitude of each stop in the table is located at third and fourth column
        var blueLineDBLatLong = new google.maps.LatLng(blueLineSingleElement[2], blueLineSingleElement[3]);
        var meters = google.maps.geometry.spherical.computeDistanceBetween(currentPosition, blueLineDBLatLong);
        var miles = meters * converstionFactor;
        miles = miles.toFixed(2);
        if (i == 0) {
            blueLineLeastMileDistance = miles;
            blueLineNearestStopDetails = blueLineSingleElement;
        }
        else {
            if (miles < redLineLeastMileDistance) {
                blueLineLeastMileDistance = miles;
                blueLineNearestStopDetails = blueLineSingleElement;
            }
        }
    }
}



// Make a HTTP GET Request for the URL and returns the response as plain text
function GetXMLHttpResponseAsText(baseURL) {
    var xmlHttp = null;
    xmlHttp = new XMLHttpRequest();
    xmlHttp.open("GET", baseURL, false);
    xmlHttp.send(null);
    return xmlHttp.responseText;
}


// The below function is responsible for plotting all the lat long in google maps
function DrawTheGoogleMaps(currentPosition, greenPosition, orangePosition, redPosition, bluePosition) {

    // Icons which will be used to place on the respective positions
    /*
    var yellowIcon = "http://maps.google.com/mapfiles/ms/icons/yellow.png";
    var greenIcon = "http://maps.google.com/mapfiles/ms/icons/green.png";
    var orangeIcon = "http://maps.google.com/mapfiles/ms/icons/orange.png";
    var redIcon = "http://maps.google.com/mapfiles/ms/icons/red.png";
    var blueIcon = "http://maps.google.com/mapfiles/ms/icons/blue.png";
    */

    var yourPlaceIcon = "resources/your-place.png";
    var greenIcon = "resources/green-stop.png";
    var orangeIcon = "resources/orange-stop.png";
    var redIcon = "resources/red-stop.png";
    var blueIcon = "resources/blue-stop.png";

    // Map settings
    var mapOptions = {
        center: currentPosition,
        zoom: 15,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    }

    // Loading the map in the corresponding division
    var gMap = new google.maps.Map(document.getElementById('stopLocatorGoogleMaps'), mapOptions);
    var infowindow = new google.maps.InfoWindow();

    // The end users position is marked with yellow color
    var yourPlaceMarker = new google.maps.Marker({
        position: currentPosition,
        map: gMap,
        title: "You Are Now Here !!",
        animation: google.maps.Animation.DROP,
        icon: yourPlaceIcon
    });

    // Animation effects when the end user places the mouse at his/her position
    google.maps.event.addListener(yourPlaceMarker, 'mouseover', function () {
        infowindow.setContent(this.title);
        infowindow.open(gMap, this);
        if (yourPlaceMarker.getAnimation() != null) { yourPlaceMarker.setAnimation(null); }
        else { yourPlaceMarker.setAnimation(google.maps.Animation.BOUNCE); }
    });



    // Nearest green line marker
    var greeLineMarker = new google.maps.Marker({
        position: greenPosition,
        map: gMap,
        // Using the global variable which holds the nearest green line stop name
        title: greenLineNearestStopDetails[1],
        animation: google.maps.Animation.DROP,
        icon: greenIcon
    });

    google.maps.event.addListener(greeLineMarker, 'mouseover', function () {
        infowindow.setContent(this.title);
        infowindow.open(gMap, this);
    });


    // Nearest orange line marker
    var orangeLineMarker = new google.maps.Marker({
        position: orangePosition,
        map: gMap,
        // Using the global variable which holds the nearest orange line stop name
        title: orangeLineNearestStopDetails[1],
        animation: google.maps.Animation.DROP,
        icon: orangeIcon
    });

    google.maps.event.addListener(orangeLineMarker, 'mouseover', function () {
        infowindow.setContent(this.title);
        infowindow.open(gMap, this);
    });


    // Nearest red line marker
    var redLineMarker = new google.maps.Marker({
        position: redPosition,
        map: gMap,
        // Using the global variable which holds the nearest red line stop name
        title: redLineNearestStopDetails[1],
        animation: google.maps.Animation.DROP,
        icon: redIcon
    });

    google.maps.event.addListener(redLineMarker, 'mouseover', function () {
        infowindow.setContent(this.title);
        infowindow.open(gMap, this);
    });


    // Nearest blue line marker
    var blueLineMarker = new google.maps.Marker({
        position: bluePosition,
        map: gMap,
        // Using the global variable which holds the nearest blue line stop name
        title: blueLineNearestStopDetails[1],
        animation: google.maps.Animation.DROP,
        icon: blueIcon
    });

    google.maps.event.addListener(blueLineMarker, 'mouseover', function () {
        infowindow.setContent(this.title);
        infowindow.open(gMap, this);
    });

}


