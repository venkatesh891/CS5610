﻿$(document).ready(function () {

    var isPostBack = false;
    if (isPostBack)
    {
        DisplayAlertBox(messageContents)
    }

});


function DisplayAlertBox(messageContents)
{
    document.getElementById("myModalWindowContents").innerHTML = messageContents;
    $('#popup').bPopup({
        speed: 650,
        transition: 'slideIn'
    });

}
