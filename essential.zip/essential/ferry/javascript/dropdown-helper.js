
// Retrieves the available stop names from mongo db and loads the boarding place drop down
function getStopNames()
{

	if(isDebugMode){
		var stopNamesArray = [];
		baseURL = "https://api.mongolab.com/api/1/databases/mbtaferry/collections/stop_details?f={'stop_name': 1}&apiKey=";
		constructedURL = baseURL + mongoAPIKey;
		$.getJSON(constructedURL, function(stopNameObjects) {
			for(var i=0; i<stopNameObjects.length; i++){
				stopNamesArray.push(stopNameObjects[i].stop_name);
			}
			loadBoardingPlacesFromMongoDB(stopNamesArray);
			boardingPlaceChanged();
		});
	}
	else{
		var baseURL = "../getkey.aspx?";
		var constructedURL = baseURL + "mongodbferry";
		$.get(constructedURL, function(data) {
			mongoAPIKey = data;
			constructedURL = baseURL + "ferry";
			$.get(constructedURL, function(data) {
				mbtaAPIKey = data;
				var stopNamesArray = [];
				baseURL = "https://api.mongolab.com/api/1/databases/mbtaferry/collections/stop_details?f={'stop_name': 1}&apiKey=";
				constructedURL = baseURL + mongoAPIKey;
				$.getJSON(constructedURL, function(stopNameObjects) {
					for(var i=0; i<stopNameObjects.length; i++){
						stopNamesArray.push(stopNameObjects[i].stop_name);
					}
					loadBoardingPlacesFromMongoDB(stopNamesArray);
					boardingPlaceChanged();
				});	
			});
		});
	}	
}


// Retrieves the reachable stop names from mongo db and loads them in the destination place drop down
function getReachableStops(stopName){
	var baseURL1 = "https://api.mongolab.com/api/1/databases/mbtaferry/collections/stop_details?q={'stop_name':'";
	var baseURL2 = "'}&f={'reachable_stops': 1}&apiKey=";
	var constructedURL = baseURL1 + stopName + baseURL2 + mongoAPIKey;
	$.getJSON(constructedURL, function(reachableStopObjects) {
    	var reachableStopsArray = reachableStopObjects[0].reachable_stops;
    	loadDestinationPlaces(reachableStopsArray);
	});
}



