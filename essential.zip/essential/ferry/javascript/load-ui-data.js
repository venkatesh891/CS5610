
// Waits Until DOM Is Ready
$(document).ready(function () {

	// Home Page Alerts
	// var msgContents = "Hello Visitor! Happy to see you back. MBTA-Ferry to view the schedule of ferry. Suggestions welcome!";
	// displayAlerts(msgContents);

	// Flag For Debugging Purpose
	isDebugMode = false;

	// Retrieves the stop names from mongo db and loads them into boarding place drop down
	getStopNames();

});

// Alerts PopUp With Custom Messages
function displayAlerts(alertMsgContents){
	document.getElementById("myModalWindowContents").innerHTML = alertMsgContents;
    $('#popup').bPopup({
        speed: 650,
        opacity: 0.5,
        transition: 'slideIn',
        transitionClose: 'slideBack'
    });
}


// Populates The Boarding Place Drop Down
function loadBoardingPlacesFromMongoDB(stopNamesArray){
	for (i=0;i<stopNamesArray.length;i++){
   		$('<option/>').val(stopNamesArray[i]).html(stopNamesArray[i]).appendTo('#ddBoardingPlace');
	}
}

// Call Back Event Fired When The Boarding Place Is Changed
function boardingPlaceChanged(){
	var boardingPlace = $('#ddBoardingPlace').val();
	getReachableStops(boardingPlace);
}

// Populates The Destination Place Drop Down
function loadDestinationPlaces(stopNamesArray){
	$('#ddDestinationPlace').empty();
	for (i=0; i<stopNamesArray.length; i++){
   		$('<option/>').val(stopNamesArray[i]).html(stopNamesArray[i]).appendTo('#ddDestinationPlace');
	}
}

// Call Back Event Fired When The Search Button Is Clicked
function searchFerry(){
	displaySpinner();
	var boardingPlace = $('#ddBoardingPlace').val();
	var destinationPlace = $('#ddDestinationPlace').val();

	loadGoogleMapVisuals(boardingPlace, destinationPlace);
	searchFerrySchedule(boardingPlace, destinationPlace);
	
	/*
	//var boardingPlaceDepartureTime = [1427038200 , 1427040000, 1427041800];
	var boardingPlaceDepartureTime = [];
	var destinationPlaceArrivalTime = [1427038800, 1427040600, 1427042400];
	populateTheScheduleDetails("tambaram", "kodambakkam", boardingPlaceDepartureTime, destinationPlaceArrivalTime);
	*/
	
}

// Starts The Spinner To Show The Search Is Happening
function displaySpinner(){
	var opts = {
		  	lines: 13, // The number of lines to draw
		  	length: 7, // The length of each line
		  	width: 4, // The line thickness
		  	radius: 10, // The radius of the inner circle
		  	corners: 1, // Corner roundness (0..1)
		  	rotate: 0, // The rotation offset
		  	color: '#000', // #rgb or #rrggbb
		  	speed: 1, // Rounds per second
		 	trail: 60, // Afterglow percentage
		  	shadow: false, // Whether to render a shadow
		  	hwaccel: false, // Whether to use hardware acceleration
		  	className: 'spinner', // The CSS class to assign to the spinner
		  	zIndex: 2e9, // The z-index (defaults to 2000000000)
		  	top: '50%', // Top position relative to parent in px
		  	left: '20%' // Left position relative to parent in px
	};

	$.fn.spin = function(opts) {
    	this.each(function() {
      	var $this = $(this),
        	  data = $this.data();
      			if (data.spinner) {
		    	    data.spinner.stop();	
		        	delete data.spinner;
		     	}
	      	if (opts !== false) {
		    	data.spinner = new Spinner($.extend({color: $this.css('color')}, opts)).spin(this);
	      	}
    	});
    	return this;
	};
	$('#scheduleSpinner').spin();
}

// Populate The UI With Ferry Schedule Details
function populateTheScheduleDetails(boardingPlace, destinationPlace, boardingPlaceDepartureTime, destinationPlaceArrivalTime) {

	$("#ferryScheduleDiv").show();
	$("#boardingPlaceName").text(boardingPlace);
	$("#destinationPlaceName").text(destinationPlace);

	if(boardingPlaceDepartureTime.length > 0 && destinationPlaceArrivalTime.length > 0) {
		EpochToNormalTime(boardingPlaceDepartureTime[0], true);
		EpochToNormalTime(destinationPlaceArrivalTime[0], false);
	}
	else {
		$("#ferryScheduleDiv").hide();
		displayAlerts("No ferry at this moment. Please try after some time.");
	}

	// Stop The Spinner
	$('#scheduleSpinner').spin(false);
}
