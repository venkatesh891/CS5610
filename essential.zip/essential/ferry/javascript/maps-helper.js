
// Display the Google Maps Visuals Based On The Boarding And Destination Place
function loadGoogleMapVisuals(boardingPlace, destinationPlace)
{
	var boardingPlaceLat, boardingPlaceLong, destinationPlaceLat, destinationPlaceLong;

	// AJAX Call To Fetch The Stop Latitude & Longitude
	var baseURL1 = "https://api.mongolab.com/api/1/databases/mbtaferry/collections/stop_details?q={'stop_name':'";
	var baseURL2 = "'}&f={'stop_lat': 1, 'stop_long':1}&apiKey=";
	var constructedURL = baseURL1 + boardingPlace + baseURL2 + mongoAPIKey;

	// Fetch Boarding Place Latitude and Longitude
	$.getJSON(constructedURL, function(data) {
		 boardingPlaceLat = data[0].stop_lat;
		 boardingPlaceLong = data[0].stop_long;

		 // Fetch Destination Place Latitude and Longitude
		 constructedURL = baseURL1 + destinationPlace + baseURL2 + mongoAPIKey;
		$.getJSON(constructedURL, function(data) {
			destinationPlaceLat = data[0].stop_lat;
			destinationPlaceLong = data[0].stop_long;

			var boardingPlacePosition = new google.maps.LatLng(boardingPlaceLat, boardingPlaceLong);
			var destinationPlacePosition = new google.maps.LatLng(destinationPlaceLat, destinationPlaceLong);

			drawGoogleMapRoute(boardingPlace, boardingPlacePosition, destinationPlace, destinationPlacePosition);

		});
	});	
	
}

// Plots the near bt stop location over Google Maps
function drawGoogleMapRoute(boardingPlace, boardingPlacePosition, destinationPlace, destinationPlacePosition){

	var boardingPlaceIcon = "images/boarding-place.png";
	var destinationPlaceIcon = "images/destination-place.png";

	 var mapOptions = {
        center: boardingPlacePosition,
        zoom: 11,
        mapTypeId: google.maps.MapTypeId.ROADMAP
    }

    // Loading the map at respective div tag
    var gMap = new google.maps.Map(document.getElementById('googleMapsDiv'), mapOptions);
    var infowindow = new google.maps.InfoWindow();

    // Boarding Place Marker
    var boardingPlaceMarker = new google.maps.Marker({
        position: boardingPlacePosition,
        map: gMap,
        // Using the global variable which holds the boarding place name
        title: boardingPlace,
        animation: google.maps.Animation.DROP,
        icon: boardingPlaceIcon
    });

    google.maps.event.addListener(boardingPlaceMarker, 'mouseover', function () {
        infowindow.setContent(this.title);
        infowindow.open(gMap, this);
    });

     // Destination Place Marker
    var destinationPlaceMarker = new google.maps.Marker({
        position: destinationPlacePosition,
        map: gMap,
        // Using the global variable which holds the destination place name
        title: destinationPlace,
        animation: google.maps.Animation.DROP,
        icon: destinationPlaceIcon
    });

    google.maps.event.addListener(destinationPlaceMarker, 'mouseover', function () {
        infowindow.setContent(this.title);
        infowindow.open(gMap, this);
    });

    // Polyline between boarding and destination place
    var lineSymbol = {
        path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
        scale: 5,
        strokeColor: '#4775d1'
    };

    var ferryPlanCoordinates = [boardingPlacePosition, destinationPlacePosition];
    var ferryPath = new google.maps.Polyline({
        path: ferryPlanCoordinates,
        
        icons: [{
            icon: lineSymbol,
            offset: '100%'
        }],
       
        strokeColor: '#4d79ff',
        strokeOpacity: 1.0,
        strokeWeight: 2,
        map: gMap
    });
    animatePolyline(ferryPath);

}

// Animation for the polyline. Use the DOM setInterval() function to change the offset of the symbol at fixed intervals.
function animatePolyline(ferryPath) {
    var count = 0;
    window.setInterval(function() {
      count = (count + 1) % 200;

      var icons = ferryPath.get('icons');
      icons[0].offset = (count / 2) + '%';
      ferryPath.set('icons', icons);
  }, 20);
}




