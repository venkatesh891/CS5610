
var boardingPlaceStopID, destinationPlaceStopID;

// Loads the API Key through Prof Rasala GetKey service
function searchFerrySchedule(boardingPlace, destinationPlace)
{	
	getBoardingPlaceStopID(boardingPlace);
	getDesintaionPlaceStopID(destinationPlace);

	var baseURL1 = "https://api.mongolab.com/api/1/databases/mbtaferry/collections/stop_details?q={'stop_name':'";
	var baseURL2 = "'}&f={'route_ids': 1}&apiKey=";
	var constructedURL = baseURL1 + boardingPlace + baseURL2 + mongoAPIKey;
	// Fetch The Boarding Place Route ID
	$.getJSON(constructedURL, function(data) {
    	var boardingPlaceRouteIDs = data[0].route_ids;
    	constructedURL = baseURL1 + destinationPlace + baseURL2 + mongoAPIKey;
    	// Fetch The Destination Place Route ID
		$.getJSON(constructedURL, function(data) {
			destinationPlaceRouteIDs = data[0].route_ids;
			// Find the matching route id's between boarding and destination place
			var matchingRouteIDs = findMatchingRouteIDs(boardingPlaceRouteIDs, destinationPlaceRouteIDs);
			findDirection(boardingPlace, destinationPlace, matchingRouteIDs);

		});
	});

}


// Fetches The Stop ID For The Boarding Place
function getBoardingPlaceStopID(boardingPlace)
{
	var baseURL1 = "https://api.mongolab.com/api/1/databases/mbtaferry/collections/stop_details?q={'stop_name':'";
	var baseURL2 = "'}&f={'stop_id': 1}&apiKey=";
	var constructedURL = baseURL1 + boardingPlace + baseURL2 + mongoAPIKey;
	// Fetch The Boarding Place Stop ID
	$.getJSON(constructedURL, function(data) {
    	boardingPlaceStopID = data[0].stop_id;
	});	
}

// Fetches The Stop ID For The Destination Place
function getDesintaionPlaceStopID(destinationPlace)
{
	var baseURL1 = "https://api.mongolab.com/api/1/databases/mbtaferry/collections/stop_details?q={'stop_name':'";
	var baseURL2 = "'}&f={'stop_id': 1}&apiKey=";
	var constructedURL = baseURL1 + destinationPlace + baseURL2 + mongoAPIKey;
	// Fetch The Destination Place Stop ID
	$.getJSON(constructedURL, function(data) {
    	destinationPlaceStopID = data[0].stop_id;
	});	
}


// Finds The Matching RouteID's For The Boarding & Destination Place
function findMatchingRouteIDs(boardingPlaceRouteIDs, destinationPlaceRouteIDs)
{
	var matchingRouteIDs = [];
	for(var i=0 ; i< boardingPlaceRouteIDs.length ; i++)
	{
		for(var j=0 ; j<destinationPlaceRouteIDs.length ; j++)
		{
			if(boardingPlaceRouteIDs[i] == destinationPlaceRouteIDs[j])
			{
				matchingRouteIDs.push(boardingPlaceRouteIDs[i]);
			}
		}
	}
	return matchingRouteIDs;
}


// Fetches The Direction ID (0 or 1) based on inbound or outbound
function findDirection(boardingPlace, destinationPlace, matchingRouteIDs){
	var isBoardingPlaceFound;
	var directionIDs = [];
	var baseURL1 = "http://realtime.mbta.com/developer/api/v2/stopsbyroute?api_key=";
	var baseURL2 = "&route=";
	var baseURL3 = "&format=json";
	var counter = 0;

	matchingRouteIDs.forEach(function(routeID) {
		var constructedURL = baseURL1 + mbtaAPIKey + baseURL2 + routeID + baseURL3;
		// Fetch The Response JSON data and identify whether the direction is inbound or outbound
		isBoardingPlaceFound = false;
		$.getJSON(constructedURL, function(data){
			counter++;
			var directionObject = data.direction;
			// Iterates Over Both InBound & OutBound Direction
			for(var i=0 ; i<directionObject.length ; i++){
				var stopObject = directionObject[i].stop;
				// Exit The Iteration When Direction Has Been Identified
				if(isBoardingPlaceFound){
					break;
				}

				// Iterates Over All The Stops	
				for(var j=0 ; j<stopObject.length; j++){
					var stopName = stopObject[j].stop_name;
					// Replacing stop name which holds ' e.g Hewitt's would be Hewitts
					stopName = stopName.replace("'", "");

					// Exit The Loop When Destination Place Appears First (i.e) The Direction Is Vice Versa
					if((destinationPlace == stopName) && (!isBoardingPlaceFound)){
						break;
					}

					// If The Boarding Place Appears First Then Retrieve The DirectionID
					if(boardingPlace == stopName){
						directionIDs.push(directionObject[i].direction_id);
						isBoardingPlaceFound = true;
						break;
					}	
				}
			}

			if(counter == matchingRouteIDs.length){
				fetchTheTimeSchedule(boardingPlace, destinationPlace, matchingRouteIDs, directionIDs);
			}
		});	
	});
}

// Retrieves The Ferry Schedule From MBTA API
function fetchTheTimeSchedule(boardingPlace, destinationPlace, matchingRouteIDs, directionIDs){
	var boardingPlaceDepartureTime = [];
	var destinationPlaceArrivalTime = [];
	var baseURL1="http://realtime.mbta.com/developer/api/v2/schedulebyroute?api_key=";
	var baseURL2 = "&route=";
	var baseURL3 = "&direction=";
	var baseURL4 = "&format=json";
	var isBoardingPlaceFound;
	var isDestinationPlaceFound;
	for(var i=0 ; i<matchingRouteIDs.length; i++)
	{
		var constructedURL = baseURL1 + mbtaAPIKey + baseURL2 + matchingRouteIDs[i] + baseURL3 + directionIDs[i] + baseURL4;
		$.getJSON(constructedURL, function(data){
			var directionObject = data.direction;
			// At some instances, the direction array is null if no service is functioning. Hence checking for null conditions.
			if(directionObject.length > 0){
				var tripObjects = data.direction[0].trip;
				// Iterate over trip objects which holds multiple ferry schedules
				tripObjects.forEach(function(trip) {
				isBoardingPlaceFound = false;
				isDestinationPlaceFound = false;
				var stopObjects = trip.stop;
				// Iterate over stop objects which holds the schedule of ferry at each stops
				stopObjects.forEach(function(stop) {
						var stopName = stop.stop_name;
						// Replacing stop name which holds ' e.g Hewitt's would be Hewitts
						stopName = stopName.replace("'", "");

						// Capture the boarding place departure time
						if(stopName == boardingPlace){
							boardingPlaceDepartureTime.push(stop.sch_dep_dt);
							isBoardingPlaceFound = true;
						}

						// Capture the destination place arrival time
						if(stopName == destinationPlace){
							destinationPlaceArrivalTime.push(stop.sch_arr_dt);
							isDestinationPlaceFound = true;
						}

					});

				// At some instance the boarding place might not be listed, removing those data from stored array
				if((!isBoardingPlaceFound) || (!isDestinationPlaceFound)){
					if(isBoardingPlaceFound){
						boardingPlaceDepartureTime.splice(i,1);
					} else {
						destinationPlaceArrivalTime.splice(i,1);
					}
				}

				});	
			}
			populateTheScheduleDetails(boardingPlace, destinationPlace, boardingPlaceDepartureTime, destinationPlaceArrivalTime);
		});
	}
}

// Converts The Epoch Time To EST
function EpochToHuman(epochTime){
	var epoch = (epochTime * 1000);
    var datum = new Date(epoch);
    return datum;
}

// Calls the service to convert epoch to normal human readable time format
function EpochToNormalTime(epochTime, isBoardingTime){
	var constructedURL = "";
	if(isDebugMode){
		constructedURL = "http://net4.ccs.neu.edu/home/venkat89/ferry/services/get-normal-time-from-epoch-time.aspx?epochTime=" + epochTime;
	}
	else {
		constructedURL = "services/get-normal-time-from-epoch-time.aspx?epochTime=" + epochTime;
	}

	$.get(constructedURL, function(data) {
		if(isBoardingTime) {
			$("#boardingTimeFerry").text(data);
		}
		else {
			$("#destinationReachTimeFerry").text(data);
		}
	});
	
}

