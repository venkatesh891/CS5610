﻿
$(document).ready(function () {
    
    //displayFerryProject();
    activateCarousel();

});

function displayFerryProject() {
    var msgContents = "Hello Visitor! Happy to see you back. I am currently working on new project <b>(MBTA-Ferry)</b>. Please stay tuned for more information. Suggestions welcome! </br></br>";
    msgContents += "Technologies Used: </br/> -> HTML-5 </br> -> CSS3 </br> -> Bootstrap </br> -> jQuery </br> -> MongoDB </br> </br>";
    msgContents += "Updates: </br/> -> Boarding and Destination Place Are Pulled From MongoDB. </br> -> Destination Place Is Populated Based Upon Boarding Place Selection. </br> -> Integrated Google Maps. Hit 'Search' button to view the map visuals! </br> -> Added Loading Spinner & Parsing of MBTA REST API JSON Data is complete. UI Polishing Alone Is Pending :-) </br> </br>";
    msgContents += " <a href='ferry/index.html' target='_blank'>MBTA-FERRY</a>";
    document.getElementById("myModalWindowContents").innerHTML = msgContents;
    $('#popup').bPopup({
        speed: 650,
        transition: 'slideIn'
    });
}

function activateCarousel()
{
    $('.carousel').carousel({
            interval: 5000 //changes the speed
        });
}

