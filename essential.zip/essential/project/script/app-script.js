﻿
$(document).ready(function () {

    // Below function handles the navigation bar click events
    $('.nav a').click(function () {

        ClearGreenLineContents();
        ClearOrangeLineContents();
        ClearRedLineContents();
        ClearBlueLineContents();
        HideStopLocatorGoogleMapsDiv();
        $('.nav a').removeClass('selected');
        var hrefID = $(this).attr('id');
        var targetDiv = "";

        if (hrefID == "greenTab") {
            targetDiv = "greenLineDivID";
            LoadGreenLineBodyBackgroundImage();
            HideDirectGreenLineTrainScheduleSection();
            HideHopGreenLineTrainScheduleSection();
        }
        else if (hrefID == "orangeTab") {
            targetDiv = "orangeLineDivID";
            LoadOrangeLineBodyBackgroundImage();
            HideOrangeLineTrainScheduleDiv();
        }
        else if (hrefID == "redTab") {
            targetDiv = "redLineDivID";
            LoadRedLineBodyBackgroundImage();
            HideRedLineTrainScheduleDiv();
        }
        else if (hrefID == "blueTab") {
            targetDiv = "blueLineDivID";
            LoadBlueLineBodyBackgroundImage();
            HideBlueLineTrainScheduleDiv();
        }
        else {
            targetDiv = "entireStopLocatorMapsDiv";
            PlotTheNearestStopInGoogleMaps();
        }

        $(this).addClass('selected');
        document.getElementById(targetDiv).style.display = "block";
    });


    // On the page load, the green line would be selected by default
    if (!isPostBack) {
        $('.nav-pills a:first').click();

        // Display modal window alert when the MBTA Service is down. MBTA doesnt operate during (00:30 - 05:30)
        if (isMBTAShutDown) {
            var mbtaClosedMessage = "MBTA doesnt operate during 00:30 - 05:30 :( ";
            DisplayModalWindow(mbtaClosedMessage);
        }
    }
        // If the event is just a post back then stay on the same page
    else {
        // 1 -> GreenLine
        // 2 -> OrangeLine
        // 3 -> RedLine
        // 4 -> BlueLine

        HideStopLocatorGoogleMapsDiv();

        if (lineCode == 1) {
            LoadGreenLineBodyBackgroundImage();
        }
        else if (lineCode == 2) {
            LoadOrangeLineBodyBackgroundImage();
        }
        else if (lineCode == 3) {
            LoadRedLineBodyBackgroundImage();
        }
        else {
            LoadBlueLineBodyBackgroundImage();
        }

    }


});

// The below function displays the modal window for alerts
function DisplayModalWindow(messageContents) {
    document.getElementById("myModalWindowContents").innerHTML = messageContents;
    $('#popup').bPopup({
        speed: 650,
        transition: 'slideIn'
    });
}


// The below function loads the background image with green line train pictures
function LoadGreenLineBodyBackgroundImage() {
    $('body').css('background-image', 'url(resources/bg-green-line.jpg)');
    $('body').css('background-repeat', 'no-repeat');
    $('body').css('background-position','center');
}

// The below function loads the background image for orange line tab
function LoadOrangeLineBodyBackgroundImage() {
    $('body').css('background-image', 'url(resources/bg-orange-line.jpg)');
    $('body').css('background-repeat', 'no-repeat');
    $('body').css('background-position', 'center');
}

// The below function loads the background image for red line tab
function LoadRedLineBodyBackgroundImage() {
    $('body').css('background-image', 'url(resources/bg-red-line.jpg)');
    $('body').css('background-repeat', 'no-repeat');
    $('body').css('background-position', 'center');
}

// The below function loads the background image for blue line tab
function LoadBlueLineBodyBackgroundImage() {
    $('body').css('background-image', 'url(resources/bg-blue-line.jpg)');
    $('body').css('background-repeat', 'no-repeat');
    $('body').css('background-position', 'center');
}

// The below function loads the background image for blue line tab
function LoadNearByStopLocatorBodyBackgroundImage() {
   // $('body').css('background-image', 'url(resources/bg-blue-line.jpg)');
   // $('body').css('background-repeat', 'no-repeat');
   // $('body').css('background-position', 'center');
}

// The below function auto populates the Green Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteGreenLineBoardingStopNames() {
    var stopNameFromUser = $("input#txtGreenLineBoardingPoint").val().trim();

    jQuery.ajax({
        url: 'services/get-green-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtGreenLineBoardingPoint").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }
    });
}


// The below function auto populates the Green Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteGreenLineDestinationStopNames() {
    var stopNameFromUser = $("input#txtGreenLineDestinationPoint").val().trim();

    jQuery.ajax({
        url: 'services/get-green-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtGreenLineDestinationPoint").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }

    });
}


// The below function auto populates the Orange Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteOrangeLineBoardingStopNames() {
    var stopNameFromUser = $("input#txtOrangeLineBoardingPoint").val().trim();

    jQuery.ajax({
        url: 'services/get-orange-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtOrangeLineBoardingPoint").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }
    });
}


// The below function auto populates the Orange Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteOrangeLineDestinationStopNames() {
    var stopNameFromUser = $("input#txtOrangeLineDestinationPoint").val().trim();

    jQuery.ajax({
        url: 'services/get-orange-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtOrangeLineDestinationPoint").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }

    });
}


// The below function auto populates the Red Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteRedLineBoardingStopNames() {
    var stopNameFromUser = $("input#txtRedLineBoardingPoint").val().trim();

    jQuery.ajax({
        url: 'services/get-red-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtRedLineBoardingPoint").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }
    });
}


// The below function auto populates the Red Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteRedLineDestinationStopNames() {
    var stopNameFromUser = $("input#txtRedLineDestinationPoint").val().trim();

    jQuery.ajax({
        url: 'services/get-red-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtRedLineDestinationPoint").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }

    });
}


// The below function auto populates the Blue Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteBlueLineBoardingStopNames() {
    var stopNameFromUser = $("input#txtBlueLineBoardingPoint").val().trim();
    jQuery.ajax({
        url: 'services/get-blue-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtBlueLineBoardingPoint").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            // alert(errorMessage);
        }
    });
}


// The below function auto populates the Blue Line Stop Names which ease the user to select his station.
// This function will be triggered upon onkeyup event
function AutoCompleteBlueLineDestinationStopNames() {
    var stopNameFromUser = $("input#txtBlueLineDestinationPoint").val().trim();

    jQuery.ajax({
        url: 'services/get-blue-line-stop-name.aspx',
        type: "GET",
        data: "StopName=" + stopNameFromUser,
        cache: false,
        success: function (data) {
            var dataFromServer = data.split("\n");
            $("input#txtBlueLineDestinationPoint").autocomplete({
                source: dataFromServer
            });
        },
        error: function (XMLHttpRequest, errorMessage, errorThrown) {
            alert(errorMessage);
        }

    });
}


// The below function clears the boarding, destination, table result contents
// This function will be triggered upon the "Clear" button click event
function ClearGreenLineContents() {
    document.getElementById('txtGreenLineBoardingPoint').value = "";
    document.getElementById('txtGreenLineDestinationPoint').value = "";
    document.getElementById('firstGreenTotalTravel').innerHTML = "";
    document.getElementById('firstGreenJourneyStartPlace').innerHTML = "";
    document.getElementById('firstGreenJourneyEndPlace').innerHTML = "";
    document.getElementById('firstGreenArrival').innerHTML = "";
    document.getElementById("firstGreenReaches").innerHTML = "";
    document.getElementById("firstGreenDurationSpan").innerHTML = "";

    document.getElementById('hopGreenTotalTravel').innerHTML = "";
    document.getElementById('hopGreenJourneyStartPlace').innerHTML = "";
    document.getElementById('hopGreenJourneyEndPlace').innerHTML = "";
    document.getElementById('hopGreenArrival').innerHTML = "";
    document.getElementById("hopGreenReaches").innerHTML = "";
    document.getElementById("hopGreenDurationSpan").innerHTML = "";

    document.getElementById("greenLineGoogleMaps").style.display = 'none';
    document.getElementById('orangeLineDivID').style.display = 'none';
    document.getElementById('redLineDivID').style.display = 'none';
    document.getElementById('blueLineDivID').style.display = 'none';
}


// The below function sets the display property of the Section to block
function DisplayDirectGreenLineTrainScheduleSection() {
    document.getElementById("directGreenLineTrainScheduleSection").style.display = 'block';
}


// The below function sets the display property of the section to block
function DisplayHopGreenLineTrainScheduleSection() {
    document.getElementById("hopGreenLineTrainScheduleSection").style.display = 'block';
}


// The below function sets the display property of the section to block
function HideDirectGreenLineTrainScheduleSection() {
    document.getElementById("directGreenLineTrainScheduleSection").style.visibility = 'hidden';
}


// The below function sets the display property of the section to block
function HideHopGreenLineTrainScheduleSection() {
    document.getElementById("hopGreenLineTrainScheduleSection").style.visibility = 'hidden';
}


// The below function clears the boarding, destination, table result contents
// This function will be triggered upon the "Clear" button click event
function ClearOrangeLineContents() {
    document.getElementById('txtOrangeLineBoardingPoint').value = "";
    document.getElementById('txtOrangeLineDestinationPoint').value = "";
    document.getElementById('firstOrangeTotalTravel').innerHTML = "";
    document.getElementById('firstOrangeJourneyStartPlace').innerHTML = "";
    document.getElementById('firstOrangeJourneyEndPlace').innerHTML = "";
    document.getElementById('firstOrangeArrival').innerHTML = "";
    document.getElementById("firstOrangeReaches").innerHTML = "";
    document.getElementById("firstOrangeDurationSpan").innerHTML = "";
    document.getElementById("orangeLineGoogleMaps").style.display = 'none';
    document.getElementById('greenLineDivID').style.display = 'none';
    document.getElementById('redLineDivID').style.display = 'none';
    document.getElementById('blueLineDivID').style.display = 'none';
}


// The below function sets the display property of the division to block
function DisplayOrangeLineTrainScheduleDiv() {
    document.getElementById("orangeLineTrainScheduleDiv").style.display = 'block';
}


// The below function sets the display property of the division to block
function HideOrangeLineTrainScheduleDiv() {
    document.getElementById("orangeLineTrainScheduleDiv").style.visibility = 'hidden';
}


// The below function clears the boarding, destination, table result contents
// This function will be triggered upon the "Clear" button click event
function ClearRedLineContents() {
    document.getElementById('txtRedLineBoardingPoint').value = "";
    document.getElementById('txtRedLineDestinationPoint').value = "";
    document.getElementById('firstRedTotalTravel').innerHTML = "";
    document.getElementById('firstRedJourneyStartPlace').innerHTML = "";
    document.getElementById('firstRedJourneyEndPlace').innerHTML = "";
    document.getElementById('firstRedArrival').innerHTML = "";
    document.getElementById("firstRedReaches").innerHTML = "";
    document.getElementById("firstRedDurationSpan").innerHTML = "";
    document.getElementById("redLineGoogleMaps").style.display = 'none';
    document.getElementById('greenLineDivID').style.display = 'none';
    document.getElementById('orangeLineDivID').style.display = 'none';
    document.getElementById('blueLineDivID').style.display = 'none';
}


// The below function sets the display property of the division to block
function DisplayRedLineTrainScheduleDiv() {
    document.getElementById("redLineTrainScheduleDiv").style.display = 'block';
}


// The below function sets the display property of the division to block
function HideRedLineTrainScheduleDiv() {
    document.getElementById("redLineTrainScheduleDiv").style.visibility = 'hidden';
}


// The below function clears the boarding, destination, table result contents
// This function will be triggered upon the "Clear" button click event
function ClearBlueLineContents() {
    document.getElementById('txtBlueLineBoardingPoint').value = "";
    document.getElementById('txtBlueLineDestinationPoint').value = "";
    document.getElementById('firstBlueTotalTravel').innerHTML = "";
    document.getElementById('firstBlueJourneyStartPlace').innerHTML = "";
    document.getElementById('firstBlueJourneyEndPlace').innerHTML = "";
    document.getElementById('firstBlueArrival').innerHTML = "";
    document.getElementById("firstBlueReaches").innerHTML = "";
    document.getElementById("firstBlueDurationSpan").innerHTML = "";
    document.getElementById("blueLineGoogleMaps").style.display = 'none';
    document.getElementById('greenLineDivID').style.display = 'none';
    document.getElementById('orangeLineDivID').style.display = 'none';
    document.getElementById('redLineDivID').style.display = 'none';
}


// The below function sets the display property of the division to block
function DisplayBlueLineTrainScheduleDiv() {
    document.getElementById("blueLineTrainScheduleDiv").style.display = 'block';
}


// The below function sets the display property of the division to block
function HideBlueLineTrainScheduleDiv() {
    document.getElementById("blueLineTrainScheduleDiv").style.visibility = 'hidden';
}


// The below function sets the display property of the division to block
function HideStopLocatorGoogleMapsDiv() {
   // document.getElementById("entireStopLocatorMapsDiv").style.visibility = 'hidden';
    document.getElementById("entireStopLocatorMapsDiv").style.display = 'none';
}
